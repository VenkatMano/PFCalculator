package com.apache.pfcalculator.BulkDataCreator;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Logger;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;

import com.apache.pfcalculator.model.Employee;

public class BulkDataCreator {
	
	Logger logger = Logger.getGlobal();
	Random rand = new Random();
	public static void main(String[] args) throws IOException
	{
		BulkDataCreator object = new BulkDataCreator();
		
		object.createUniqueDatas();
	}
	
	public void createUniqueDatas() throws IOException
	{
		logger.info("Starting to create unique set of datas");
		Scanner in = new Scanner(System.in);
		int count = in.nextInt();
		Random rand = new Random();
		String fileName = "employee";
		long startMillis = new Date(946684800).getTime();
	    long endMillis = new Date(1590883200).getTime();
	    File file = new File("D"+":"+File.separator+"Bulk_Upload");
		for(int i=0; i<count; i++)
		{
			Employee employee = new Employee();
			employee.setAadharId(generateRandomAaadharIds());
			employee.setEmailId(generateRandomEmailIds(12));
			employee.setFirstName(generateRandomNames());
			employee.setLastName(generateRandomNames());
			employee.setPanCardId(generateRandomPanID());
			employee.setPfStartDate(new Date(ThreadLocalRandom
				      .current()
				      .nextLong(startMillis, endMillis)));
			employee.setRole("software engineer");
			employee.setSalary(generateRandomSalary());
			employee.setTotalPfInAccount(generateRandomPf());			
			if(!file.exists())
			{
				file.mkdirs();
			}
			File toCreateFile = new File("D"+":"+File.separator+"Bulk_Upload"+File.separator+fileName+ (i+1)+".json");
			toCreateFile.createNewFile();
			JSONObject json = new JSONObject(employee);
			FileOutputStream out  = new FileOutputStream(toCreateFile);
			InputStream inputStream = new ByteArrayInputStream(json.toString().getBytes());
			IOUtils.copy(inputStream, out);			
		}
		ZipFileCreator zipObject = new ZipFileCreator();
		zipObject.createZipFortheFollowingFolder(file);
		
	}
	
	public String generateRandomEmailIds(int length) {
		String aadharCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder sb = new StringBuilder();		
		while(sb.length()<=length)
		{
			int index = (rand.nextInt(aadharCharacters.length()));
			sb.append(aadharCharacters.charAt(index));
		}
		return sb.toString()+"@test.com";
	}
	
	public String generateRandomAaadharIds() {
		String aadharCharacters = "1234567890";
		StringBuilder sb = new StringBuilder();		
		while(sb.length()<13)
		{
			int index = rand.nextInt(aadharCharacters.length());
			sb.append(aadharCharacters.charAt(index));
		}
		return sb.toString();
	}
	
	public Long generateRandomSalary() {
		String aadharCharacters = "1234567890";
		StringBuilder sb = new StringBuilder();		
		while(sb.length()<6)
		{
			int index = rand.nextInt(aadharCharacters.length());
			sb.append(aadharCharacters.charAt(index));
		}
		return Long.valueOf(sb.toString());
	}
	
	public Long generateRandomPf() {
		String aadharCharacters = "1234567890";
		StringBuilder sb = new StringBuilder();		
		while(sb.length()<7)
		{
			int index = rand.nextInt(aadharCharacters.length());
			sb.append(aadharCharacters.charAt(index));
		}
		return Long.valueOf(sb.toString());
	}
	
	public String generateRandomNames() {
		String aadharCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuilder sb = new StringBuilder();		
		while(sb.length()<10)
		{
			int index = rand.nextInt(aadharCharacters.length());
			sb.append(aadharCharacters.charAt(index));
		}
		return sb.toString();
	}
	
	public String generateRandomPanID() {
		String aadharCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder sb = new StringBuilder();		
		while(sb.length()<11)
		{
			int index = (rand.nextInt(aadharCharacters.length()));
			sb.append(aadharCharacters.charAt(index));
		}
		return sb.toString();
	}

}
