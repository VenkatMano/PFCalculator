package com.apache.pfcalculator.BulkDataCreator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;

public class ZipFileCreator {
	
	public void createZipFortheFollowingFolder(File folderName) throws IOException
	{
		File file = new File(folderName.getAbsolutePath()+File.separator+"sample.zip");
		file.createNewFile();
		FileOutputStream fos = new FileOutputStream(file);
		ZipOutputStream zos = new ZipOutputStream(fos);
		File[] lisofFiles = folderName.listFiles();
		for(File fileToZip : lisofFiles)
		{			
			String filePath = fileToZip.getAbsolutePath();
			if(!filePath.contains(".zip"))
			{
				ZipEntry ze = new ZipEntry(filePath.substring(folderName.getAbsolutePath().length()+1, filePath.length()));
				zos.putNextEntry(ze);
				FileInputStream fis = new FileInputStream(fileToZip);
				IOUtils.copy(fis, zos);
				zos.closeEntry();
				fis.close();
				fileToZip.delete();
			}						
		}		
		zos.close();
	}

}
